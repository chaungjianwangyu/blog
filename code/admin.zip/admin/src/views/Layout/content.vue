<template>
    <div class="content-wrapper">
        <transition>
            <router-view></router-view>
        </transition>
    </div>
</template>
